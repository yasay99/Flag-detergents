import React from 'react'
import '../components/Foot.css'
function Footer() {
  return (
    <div>
      <div className="Last">
      <nav >
          <h1 className='Secc-tit'>Contact us</h1>
           <p className='FF-para'>Location📍:Merkato,Bombtera</p>
           <p className='FF-para'>Phone number📞: <a href=''>+251-911212068</a> </p>
           
       
      </nav>
    </div>
    </div>
  )
}

export default Footer
